The following directory contains the DQI dataset (Europolis) with automatically annotated linguistic features
and manually annotated Argument Quality scores.
The data can be used to replicate the experiments from:
Neele Falk and Gabriella Lapesa: "Scaling up Discourse Quality Annotation for Political Science"

The data can only be used for research purposes.
Please contact neele.falk@ims.uni-stuttgart.de to retrieve the actual text corresponding to the IDs.

EuropolisWithFeatures.csv
contains the pre-processed Europolis dataset (Gerber 2018) with comment IDs and automatic features.

EuropolisAQ.csv
contains a subset of Europolis, annotated with Argument Quality.

5foldCVEuropolis
contains the IDs and features used for Experiment 1

5foldCVEuropolisAQ
contains the IDs and features used for Experiment 2